import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.baeldung.scope.prototype.PrototypeBean;
import com.baeldung.scope.singletone.SingletonBean;

public class Application {

	public static void main(String[] args) throws InterruptedException {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		SingletonBean firstSingleton = context.getBean(SingletonBean.class);
		PrototypeBean firstPrototype = firstSingleton.getPrototypeBean();

		// get singleton bean instance one more time
		SingletonBean secondSingleton = context.getBean(SingletonBean.class);
		PrototypeBean secondPrototype = secondSingleton.getPrototypeBean();

		System.out.println(firstPrototype.equals(secondPrototype));;
	}

}
