package com.capgemini.capstore.main;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MyController {

	@Autowired
	private PayPalService paypalService;

	@RequestMapping(value = "/")
	public String index(ModelMap model) {
		List<Product> products = new ArrayList<Product>();
		products.add(new Product("p01", "name 1", 20.3, 3));
		products.add(new Product("p02", "name 2", 400, 2));
		products.add(new Product("p03", "name 3", 500, 4));
		model.put("products", products);
		model.put("paypalConfig", paypalService.getPalConfig());
		return "index";
	}
}
