package com.capgemini.capstore.main;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class PayPalService {
	
	@Autowired
	private Environment environment;
	
	public PayPalConfig getPalConfig() {
		PayPalConfig payConfig = new PayPalConfig();
		payConfig.setAuthToken(environment.getProperty("paypal.authtoken"));
		payConfig.setBussiness(environment.getProperty("paypal.business"));
		payConfig.setPosturl(environment.getProperty("paypal.posturl"));
		payConfig.setReturnurl(environment.getProperty("paypal.returnurl"));
		return payConfig;
	}
	
}
