package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MyController {
	@RequestMapping(value = "/")
	public String index(ModelMap model) {
		List<Product> list=new ArrayList<Product>();
		list.add(new Product(2,"RE",200));
		list.add(new Product(3,"RE",200));		
		model.addAttribute("products",list);
		System.out.println(list);
		return "index";
	}
}
