package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacedorderApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacedorderApplication.class, args);
	}

}
