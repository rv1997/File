import java.util.List;

import com.capgemini.beans.Account;
import com.capgemini.beans.AccountService;
import com.capgemini.beans.Options;
import com.capgemini.service.AccountServiceImpl;

public class Entry {
	public static void main(String[] args) {
		Account a = new Account();
		a.setBalance(2000);
		a.setId(5);
		a.setName("Kuchb");
		AccountService service = new AccountServiceImpl();

		boolean flag = service.create(a);
		System.out.println("New Account created?" + flag);
		List<Account> accounts = service.findAll();
		System.out.println(accounts);
		accounts = service.sortAccountDetails(Options.byId);
		System.out.println(accounts);
		accounts = service.sortAccountDetails(Options.byName);
		System.out.println(accounts);
		flag=service.delete(2);
		System.out.println(flag);
		accounts=service.findAll();
		System.out.println(accounts);
		a=service.findById(1);
		System.out.println(a);

	}
}
