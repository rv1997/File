package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.capgemini.beans.Account;
import com.capgemini.beans.Options;

public class AccountDAOImpl implements AccountDAO {
	private Map<Integer, Account> accountDetails;

	public AccountDAOImpl() {
		accountDetails = new TreeMap<>();
		Account a1 = new Account();
		a1.setId(1);
		a1.setBalance(4000);
		a1.setName("Rahul");
		accountDetails.put(a1.getId(), a1);
		Account a2 = new Account();
		a2.setId(2);
		a2.setBalance(5000);
		a2.setName("Ajay");
		accountDetails.put(a2.getId(), a2);
	}

	@Override
	public List<Account> findAll() {
		List<Account> account = new ArrayList<>(accountDetails.values());
		return account;

	}

	@Override
	public List<Account> sortAccountDetails(Options option) {
		List<Account> account = new ArrayList<>(accountDetails.values());
		if (option == Options.byId) {
			class Custom implements Comparator<Account> {

				@Override
				public int compare(Account o1, Account o2) {
					// TODO Auto-generated method stub
					return o1.getName().compareTo(o2.getName());
				}
			}
			Collections.sort(account, new Custom());
		} else if (option == Options.byId) {
			class Custom implements Comparator<Account> {

				@Override
				public int compare(Account o1, Account o2) {
					// TODO Auto-generated method stub
					return o1.getId() - o2.getId();
				}
			}
			Collections.sort(account, new Custom());
		}
		return account;
	}

	@Override
	public boolean create(Account newAccount) {
		Account accountRef = accountDetails.putIfAbsent(newAccount.getId(),
				newAccount);
		if (accountRef == null)
			return true;
		else
			return false;
	}
	@Override
	public boolean delete(int id) {
		Account accountref=accountDetails.remove(id);
		System.out.println(accountref);
		if(accountref==null)
			return false;
		else
			return true;
		
	}
	@Override
	public Account findById(int id) {
		Account account=accountDetails.get(id);
		return account;
	}
	@Override
	public boolean update(int id, Account account) {
		Account flag=accountDetails.put(id, account);
		if(flag==null)
			return false;
		else 
			return true;
		
	}
}
