import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import org.junit.Test;


public class TestStringOperation {
	String expectedMessage="Hello, world!";
	String actualMessage=new String("Hello, world!");


	@Test
	public void test() {
		///fail("Not yet implemented");
		assertEquals(expectedMessage, actualMessage);
	//	assertTrue(expectedMessage.length()>0);
		
	}
	@Test
	public void test1() {
		///fail("Not yet implemented");
		//assertEquals(expectedMessage, actualMessage);
		assertTrue(expectedMessage.length()>0);
	

}
	@Test
	public void test2()
	{
		assertSame(expectedMessage,actualMessage);
	}
}
