import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Account;
import com.capgemini.dao.AccountDAO;
import com.capgemini.dao.AccountDAOImpl;


public class TestAccountDAOOperations {
	private AccountDAO daoRef;
	@Before
	public void setup()
	{
		System.out.println("Setting up DAO object");
		daoRef=new AccountDAOImpl();
	}

	@Test
	public void test() {
		Account account=new Account();
		account.setBalance(3000);
		account.setId(13);
		account.setName("Rahul");
		boolean flag=daoRef.create(account);
		assertTrue(flag);
		//fail("Not yet implemented");
		
	}
	@Test
	public void test1()
	{
		boolean flag=daoRef.delete(1);
		assertTrue(flag);
		
	}
	@Test
	public void test2()
	{
		Account temp=daoRef.findById(1);
		System.out.println(temp);
		assertTrue(temp!=null);
		
	}
	@Test
	public void test3()
	{Account account=new Account();
	account.setBalance(3000);
	account.setId(12);
	account.setName("Rahul");
	
		boolean temp=daoRef.update(12,account);
		assertFalse(temp);
		
	}
	@After
	public void tearDown()
	{
		System.out.println("Cleaning up dao Object");
		daoRef=null;
	}

}
