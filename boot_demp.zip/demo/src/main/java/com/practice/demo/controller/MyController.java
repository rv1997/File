package com.practice.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.practice.demo.person_bean.Person;
import com.practice.demo.person_service.Person_Service;
@RestController
@RequestMapping("practice")
public class MyController {
	@Autowired
	Person_Service serRef;
	@RequestMapping(method=RequestMethod.GET,value="/get")
	public List<Person> findData()
	{
		return serRef.findAll();
	}
	@RequestMapping(method=RequestMethod.POST,value="/add")
public Person addData(@RequestBody Person p)
{
	 return serRef.create(p);
}
	@RequestMapping(method=RequestMethod.DELETE,value="del/{id}")
	public List<Person> deleteData(@PathVariable(name="id") int id)
	{
		return serRef.delete(id);
	}
	@RequestMapping(method=RequestMethod.PUT,value="upd/{id}")
	public Person updateData(@RequestBody Person p,@PathVariable(name="id") int id)
	{
		return serRef.update(id, p);
	}

}
    