package com.practice.demo.person_service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.practice.demo.person_bean.Person;
import com.practice.demo.person_dao.Person_dao;
@Transactional
@Service
public class Person_Service_impl implements Person_Service {
@Autowired
Person_dao daoRef;
	@Override
	public List<Person> findAll() {
		// TODO Auto-generated method stub
		return daoRef.findAll();
	}
	public Person create(Person p)
	{
	 return daoRef.create(p);
	}
	@Override
	public List<Person> delete(int id) {
		 return daoRef.delete(id);		
	}
	@Override
	public Person update(int id,Person p) {
	return daoRef.update(id,p);	
	}
	

}
