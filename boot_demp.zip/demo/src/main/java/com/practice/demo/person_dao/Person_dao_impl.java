package com.practice.demo.person_dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.practice.demo.person_bean.Person;

import oracle.net.aso.q;
@Transactional
@Repository
public class Person_dao_impl implements Person_dao{
    @PersistenceContext 
	EntityManager entitymanager;
	@Override
	public List<Person> findAll() {
	Query query=entitymanager.createQuery("Select p from Person p");
	return query.getResultList();
	}
	@Override
	public Person create(Person p) {
		entitymanager.persist(p);
		return p;
	
	}
	@Override
	public List<Person> delete(int id) {
		Person p=entitymanager.find(Person.class, id);
		entitymanager.remove(p);
		Query query=entitymanager.createQuery("Select p from Person p");
		return query.getResultList();
			
		
	}
	@Override
	public Person update(int id,Person p) {
		p.setId(id);
		entitymanager.merge(p);	
		entitymanager.flush();
		return p;
	}
	

}
