package com.practice.demo.person_service;

import java.util.List;

import com.practice.demo.person_bean.Person;

public interface Person_Service {
	public List<Person> findAll();
	public Person create(Person p);
	public List<Person> delete(int id);
	public Person update(int id,Person p);

}
