package com.capgemini.practicedemo.repository;

import java.util.List;

import com.capgemini.practicedemo.dto.Shipwreck;

public interface ShipwreckRepository {
	public List<Shipwreck> list();
	public Shipwreck create(Shipwreck wreck);
	public  Shipwreck get(Long id);
	public Shipwreck update(Long id, Shipwreck wreck);
	public Shipwreck delete(Long id);

}
