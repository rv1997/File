import java.text.ParseException;
import java.util.Date;


public class Employee {
	private int Emp_id=0;
	private String FName;
	private String LName;
	private float salary;
	private String grade;
	Date join_date;
	Joining_Date jd=new Joining_Date(); 

	public Employee(String fName, String lName, float salary, String grade,
			String date) throws ParseException {
		++Emp_id;
		FName = fName;
		LName = lName;
		this.salary = salary;
		this.grade = grade;
		join_date=jd.modify(date);
		
	}
	public String getGrade() {
		return grade;
	}
	public String getFName() {
		return FName;
	}
	@Override
	public String toString() {
		return "Employee [Emp_id=" + Emp_id + ", FName=" + FName + ", LName="
				+ LName + ", salary=" + salary + ", grade=" + grade
				+ ", join_date=" + join_date + "]";
	}
	public String getLName() {
		return LName;
	}
	
	public float getSalary() {
		return salary;
	}
	public Date getJoin_date() {
		return join_date;
	}

}
