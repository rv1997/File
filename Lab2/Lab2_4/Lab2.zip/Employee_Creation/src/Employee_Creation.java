import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class Employee_Creation {
	public static void main(String[] args) throws ParseException {
		int i=0,count=0;
		ArrayList<Employee> emp=new ArrayList<Employee>();
		String fname,lname;
		String grade;
		float salary;
	    String date; 
		Scanner s=new Scanner(System.in);
		System.out.println("enter employee details");
		while(i!=1)
		{
			System.out.println("Enter First Name,Last Name,date,grade,salary");
			emp.add(new Employee("Rahul","Varshney",12000,"E","15-01-2019"));
			System.out.println("Enter 1 to exit");
			i=s.nextInt();
			s.nextLine();
			count++;
			}
		for(int i1=0;i1<emp.size();i1++)
			System.out.println(emp.get(i1).toString());
		System.out.println("Total Employees are"+count);
		
	}

}
