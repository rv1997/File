import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Joining_Date {
	public Date modify(String date) throws ParseException
	{
		 SimpleDateFormat df=new SimpleDateFormat("dd-MM-yyyy");
		 Date join_date;
		 join_date=df.parse(date);
		 return join_date;
	}

}
