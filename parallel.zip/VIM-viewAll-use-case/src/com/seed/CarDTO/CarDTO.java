package com.seed.CarDTO;
public class CarDTO
{
	static int count=0;
    private int id;
    private String make;
    private String model;
    private String modelYear;

    public CarDTO()
    {
    	this.id=count++;
    	this.make="";
    	this.model="";
    	this.modelYear="";
        //TODO 1 initialize id to -1 and rest of the member variables to a blank string
		
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}
    

    //TODO 2 Implement the setter and getter methods
}
