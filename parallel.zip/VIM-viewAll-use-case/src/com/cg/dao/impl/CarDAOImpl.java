package com.cg.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.dao.CarDAO;
import com.seed.CarDTO.CarDTO;

public class CarDAOImpl implements CarDAO {
     Map<Integer,CarDTO> data=new HashMap<Integer,CarDTO>();
	@Override
	public List<CarDTO> findAll()  {
		List<CarDTO> list=new ArrayList<CarDTO>(data.values());
		return list;
		// TODO Auto-generated method stub
		
	}

	@Override
	public CarDTO findById(int id)  {
		if(data.containsKey(id))
		{
		CarDTO dto=data.get(id);
		return dto;
		}
		else return null;
	}

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		data.put(car.getId(), car);
		
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		data.put(car.getId(),car);
			
		
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		for(int i=0;i<ids.length;i++)
		{
			int temp=Integer.parseInt(ids[i]);
			if(data.containsKey(temp))
				data.remove(ids[i]);
		}
		
	}

}
